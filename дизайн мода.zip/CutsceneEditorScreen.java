package com.iscript.iscript.gui.screen;

import com.iscript.iscript.client.camera.CutsceneCameraMode;
import com.iscript.iscript.client.camera.CutscenePath;
import com.iscript.iscript.client.camera.CutscenePathRenderer;
import com.iscript.iscript.client.camera.Interpolation;
import com.iscript.iscript.client.camera.CameraShake;
import com.iscript.iscript.data.cutscene.CutsceneAction;
import com.iscript.iscript.data.cutscene.CutsceneActionType;
import com.iscript.iscript.data.cutscene.CutsceneData;
import com.iscript.iscript.network.IScriptNetwork;
import com.iscript.iscript.network.packet.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import com.iscript.iscript.client.camera.PathType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CutsceneEditorScreen extends Screen {

    private static final int TOPBAR_H = 24;
    private static final int MIN_PANEL_W = 120;
    private static final int MAX_PANEL_W = 300;
    private static final int TIMELINE_H = 90;
    private static final int MIN_TIMELINE_H = 60;
    private static final int MAX_TIMELINE_H = 160;
    private static final int ICON_SIZE = 20;
    private static final int TICK_W = 2;

    private static final int ACCENT = 0xFF00D4AA;
    private static final int BG_PANEL = 0xDD1E1E2E;
    private static final int BG_TOP = 0xEE1A1A28;
    private static final int BG_INNER = 0xCC16161E;
    private static final int BG_TIMELINE = 0xE616161E;
    private static final int BG_TRACK = 0xFF111118;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFFAAAAAA;
    private static final int TEXT_MUTE = 0xFF666688;
    private static final int BORDER = 0xFF2A2A3A;
    private static final int SELECTED = 0xFF334455;
    private static final int PLAYHEAD = 0xFFFF4444;

    private int cutscenePanelW = 150;
    private int propsPanelW = 180;
    private int timelineH = TIMELINE_H;
    private boolean showCutscenes = false;
    private boolean showTimeline = false;
    private boolean showProperties = false;
    private boolean dirty = false;
    private boolean pathVisible = false;
    private boolean showAllPaths = false;
    private boolean isPlaying = false;
    private boolean draggingPlayhead = false;
    private boolean draggingAction = false;
    private boolean resizingLeft = false;
    private boolean resizingRight = false;
    private boolean resizingTimeline = false;
    private int dragActionIndex = -1;
    private int dropTargetIndex = -1;
    private int dragStartX = 0;
    private int dragOffsetX = 0;
    private int dragActionWidth = 0;
    private int playheadTick = 0;
    private float timelineScale = 1.0f;
    private int timelineOffset = 0;
    private float playSpeed = 1.0f;
    private long playStartTime = 0;
    private int playStartTick = 0;
    private int interpIndex = 0;

    private static final Map<PathType, String> PATH_TYPE_NAMES = new HashMap<>() {{
        put(PathType.LINEAR, "Вид");
        put(PathType.CATMULL_ROM, "Путь");
        put(PathType.CUBIC_BEZIER, "Безье");
        put(PathType.HERMITE, "Рельс");
        put(PathType.BSPLINE, "B-Сплайн");
        put(PathType.CIRCULAR, "Круг");
        put(PathType.ELLIPTICAL, "Эллипс");
        put(PathType.SPIRAL, "Спираль");
        put(PathType.HELIX, "Винт");
        put(PathType.STEP, "Ключ");
        put(PathType.NONE, "Ноль");
    }};

    private EditBox searchBox, nameBox;
    private EditBox xBox, yBox, zBox, yawBox, pitchBox, rollBox, durationBox, stringBox;
    private List<EditBox> spXBoxes = new ArrayList<>();
    private List<EditBox> spYBoxes = new ArrayList<>();
    private List<EditBox> spZBoxes = new ArrayList<>();
    private List<EditBox> spYawBoxes = new ArrayList<>();
    private List<EditBox> spPitchBoxes = new ArrayList<>();
    private List<IconButton> spRemoveBtns = new ArrayList<>();

    private EditBox shakeTraumaBox, shakeDecayBox, shakeAngleBox, shakeOffsetBox;
    private EditBox lookAtXBox, lookAtYBox, lookAtZBox;
    private EditBox orbitRadiusBox, orbitHeightBox, orbitSpeedBox;
    private EditBox dollyDistanceBox;

    private IconButton playBtn, pauseBtn, stopBtn, prevActionBtn, nextActionBtn;
    private IconButton addActionBtn, removeActionBtn, duplicateActionBtn, moveUpBtn, moveDownBtn;
    private IconButton saveBtn, backBtn, showPathBtn, showAllPathsBtn;
    private IconButton openCutscenesBtn, openTimelineBtn, openPropertiesBtn;
    private IconButton zoomInBtn, zoomOutBtn, zoomResetBtn;
    private Button usePosBtn, interpBtn, typeBtn, splineToggleBtn, addSplinePointBtn;
    private Button pathTypeBtn;
    private Button newCutsceneBtn, deleteCutsceneBtn, loopBtn;

    public CutsceneEditorScreen(Map<String, CutsceneData> cutscenes) {
        super(Component.literal("Cutscene Editor"));
    }

    @Override
    protected void init() {
        this.clearWidgets();
        spXBoxes.clear(); spYBoxes.clear(); spZBoxes.clear();
        spYawBoxes.clear(); spPitchBoxes.clear(); spRemoveBtns.clear();

        int cy = (TOPBAR_H - ICON_SIZE) / 2;
        int lx = 4;
        addActionBtn = new IconButton(lx, cy, ICON_SIZE, ICON_SIZE, "+", 0xFF00D4AA, Component.literal("Add Action (Ins)"), () -> {});
        removeActionBtn = new IconButton(lx + 22, cy, ICON_SIZE, ICON_SIZE, "-", 0xFFFF4444, Component.literal("Remove Action (Del)"), () -> {});
        duplicateActionBtn = new IconButton(lx + 44, cy, ICON_SIZE, ICON_SIZE, "\u29C9", 0xFF55AAFF, Component.literal("Duplicate (Ctrl+D)"), () -> {});
        moveUpBtn = new IconButton(lx + 66, cy, ICON_SIZE, ICON_SIZE, "\u25B2", 0xFFCCCCCC, Component.literal("Move Up"), () -> {});
        moveDownBtn = new IconButton(lx + 88, cy, ICON_SIZE, ICON_SIZE, "\u25BC", 0xFFCCCCCC, Component.literal("Move Down"), () -> {});
        addRenderableWidget(addActionBtn);
        addRenderableWidget(removeActionBtn);
        addRenderableWidget(duplicateActionBtn);
        addRenderableWidget(moveUpBtn);
        addRenderableWidget(moveDownBtn);

        int mx = width / 2 - 70;
        stopBtn = new IconButton(mx, cy, ICON_SIZE, ICON_SIZE, "\u25A0", 0xFFFF4444, Component.literal("Stop"), () -> {});
        prevActionBtn = new IconButton(mx + 22, cy, ICON_SIZE, ICON_SIZE, "\u23EE", 0xFFCCCCCC, Component.literal("Prev Action"), () -> {});
        playBtn = new IconButton(mx + 44, cy, ICON_SIZE, ICON_SIZE, "\u25B6", 0xFF44AA44, Component.literal("Play (Space)"), () -> {});
        pauseBtn = new IconButton(mx + 44, cy, ICON_SIZE, ICON_SIZE, "\u23F8", 0xFFFFAA44, Component.literal("Pause (Space)"), () -> {});
        pauseBtn.visible = false;
        nextActionBtn = new IconButton(mx + 66, cy, ICON_SIZE, ICON_SIZE, "\u23ED", 0xFFCCCCCC, Component.literal("Next Action"), () -> {});
        addRenderableWidget(stopBtn);
        addRenderableWidget(prevActionBtn);
        addRenderableWidget(playBtn);
        addRenderableWidget(pauseBtn);
        addRenderableWidget(nextActionBtn);

        int zx = mx + 100;
        zoomOutBtn = new IconButton(zx, cy, ICON_SIZE, ICON_SIZE, "\u2212", 0xFFCCCCCC, Component.literal("Zoom Out"), () -> {});
        zoomResetBtn = new IconButton(zx + 22, cy, ICON_SIZE, ICON_SIZE, "\u27F2", 0xFFCCCCCC, Component.literal("Reset Zoom"), () -> {});
        zoomInBtn = new IconButton(zx + 44, cy, ICON_SIZE, ICON_SIZE, "+", 0xFFCCCCCC, Component.literal("Zoom In"), () -> {});
        addRenderableWidget(zoomOutBtn);
        addRenderableWidget(zoomResetBtn);
        addRenderableWidget(zoomInBtn);

        int rx = width - 4;
        saveBtn = new IconButton(rx - 20, cy, ICON_SIZE, ICON_SIZE, "\uD83D\uDCBE", 0xFF55AAFF, Component.literal("Save (Ctrl+S)"), () -> {});
        backBtn = new IconButton(rx - 42, cy, ICON_SIZE, ICON_SIZE, "\u21A9", 0xFFFF8888, Component.literal("Back (Esc)"), () -> {});
        showPathBtn = new IconButton(rx - 64, cy, ICON_SIZE, ICON_SIZE, "\u25CE", 0xFFAA8822, Component.literal("Show Path"), () -> {});
        showAllPathsBtn = new IconButton(rx - 86, cy, ICON_SIZE, ICON_SIZE, "\u2726", 0xFF888888, Component.literal("Show All Paths"), () -> {});
        openPropertiesBtn = new IconButton(rx - 108, cy, ICON_SIZE, ICON_SIZE, "\u2699", 0xFFCCCCCC, Component.literal("Properties (P)"), () -> {});
        openTimelineBtn = new IconButton(rx - 130, cy, ICON_SIZE, ICON_SIZE, "\u29C4", 0xFFCCCCCC, Component.literal("Timeline (T)"), () -> {});
        openCutscenesBtn = new IconButton(rx - 152, cy, ICON_SIZE, ICON_SIZE, "\u2630", 0xFFCCCCCC, Component.literal("Cutscenes (C)"), () -> {});
        addRenderableWidget(saveBtn);
        addRenderableWidget(backBtn);
        addRenderableWidget(showPathBtn);
        addRenderableWidget(showAllPathsBtn);
        addRenderableWidget(openPropertiesBtn);
        addRenderableWidget(openTimelineBtn);
        addRenderableWidget(openCutscenesBtn);

        openCutscenesBtn.setColor(showCutscenes ? ACCENT : TEXT_DIM);
        openTimelineBtn.setColor(showTimeline ? ACCENT : TEXT_DIM);
        openPropertiesBtn.setColor(showProperties ? ACCENT : TEXT_DIM);

        searchBox = new EditBox(font, 0, 0, 100, 14, Component.literal("Search"));
        addRenderableWidget(searchBox);

        nameBox = new EditBox(font, 0, 0, 100, 14, Component.literal("Name"));
        addRenderableWidget(nameBox);

        newCutsceneBtn = Button.builder(Component.literal("+ New"), b -> {}).size(52, 14).build();
        deleteCutsceneBtn = Button.builder(Component.literal("Del"), b -> {}).size(36, 14).build();
        loopBtn = Button.builder(Component.literal("\u27F3 Loop"), b -> {}).size(60, 14).build();
        addRenderableWidget(newCutsceneBtn);
        addRenderableWidget(deleteCutsceneBtn);
        addRenderableWidget(loopBtn);

        int pw = propsPanelW - 8;
        typeBtn = Button.builder(Component.literal("Type: -"), b -> {}).size(pw, 14).build();
        addRenderableWidget(typeBtn);
        xBox = makeField(0, 0, pw); yBox = makeField(0, 0, pw); zBox = makeField(0, 0, pw);
        yawBox = makeField(0, 0, pw); pitchBox = makeField(0, 0, pw); rollBox = makeField(0, 0, pw);
        durationBox = makeField(0, 0, pw); stringBox = makeField(0, 0, pw);

        usePosBtn = Button.builder(Component.literal("Use My Pos"), b -> {}).size(80, 14).build();
        interpBtn = Button.builder(Component.literal("Interp: LINEAR"), b -> {}).size(pw, 14).build();
        splineToggleBtn = Button.builder(Component.literal("Spline: OFF"), b -> {}).size(pw, 14).build();
        addSplinePointBtn = Button.builder(Component.literal("+ Point"), b -> {}).size(pw, 14).build();
        addRenderableWidget(usePosBtn);
        addRenderableWidget(interpBtn);
        addRenderableWidget(splineToggleBtn);
        addRenderableWidget(addSplinePointBtn);

        pathTypeBtn = Button.builder(Component.literal("Path: CATMULL_ROM"), b -> {}).size(pw, 14).build();
        addRenderableWidget(pathTypeBtn);

        shakeTraumaBox = makeField(0, 0, pw);
        shakeDecayBox = makeField(0, 0, pw);
        shakeAngleBox = makeField(0, 0, pw);
        shakeOffsetBox = makeField(0, 0, pw);

        lookAtXBox = makeField(0, 0, pw);
        lookAtYBox = makeField(0, 0, pw);
        lookAtZBox = makeField(0, 0, pw);

        orbitRadiusBox = makeField(0, 0, pw);
        orbitHeightBox = makeField(0, 0, pw);
        orbitSpeedBox = makeField(0, 0, pw);

        dollyDistanceBox = makeField(0, 0, pw);

        layout();
    }

    private EditBox makeField(int x, int y, int width) {
        EditBox box = new EditBox(font, x + 36, y, width - 36, 12, Component.empty());
        box.setMaxLength(128);
        addRenderableWidget(box);
        return box;
    }

    private void layout() {
        int bottomY = height - (showTimeline ? timelineH : 0);
        int cutX = showCutscenes ? cutscenePanelW : 0;
        int propX = showProperties ? width - propsPanelW : width;

        searchBox.setX(4);
        searchBox.setY(TOPBAR_H + 20);
        searchBox.setWidth(cutscenePanelW - 8);
        searchBox.visible = showCutscenes;

        int btnY = height - 24;
        int btnW = Math.min(52, Math.max(36, (cutscenePanelW - 16) / 3));

        newCutsceneBtn.setX(4);
        newCutsceneBtn.setY(btnY);
        newCutsceneBtn.setWidth(btnW);
        newCutsceneBtn.visible = showCutscenes;

        deleteCutsceneBtn.setX(4 + btnW + 4);
        deleteCutsceneBtn.setY(btnY);
        deleteCutsceneBtn.setWidth(Math.min(36, btnW));
        deleteCutsceneBtn.visible = showCutscenes;

        loopBtn.setX(cutscenePanelW - 4 - btnW);
        loopBtn.setY(btnY);
        loopBtn.setWidth(btnW);
        loopBtn.visible = showCutscenes;

        nameBox.setX(propX + 4);
        nameBox.setY(TOPBAR_H + 6);
        nameBox.setWidth(propsPanelW - 8);
        nameBox.visible = showProperties;

        int py = TOPBAR_H + 24;
        int pw = propsPanelW - 8;
        typeBtn.setX(propX + 4); typeBtn.setY(py); typeBtn.setWidth(pw); py += 18;
        xBox.setX(propX + 4 + 36); xBox.setY(py); xBox.setWidth(pw - 36); py += 18;
        yBox.setX(propX + 4 + 36); yBox.setY(py); yBox.setWidth(pw - 36); py += 18;
        zBox.setX(propX + 4 + 36); zBox.setY(py); zBox.setWidth(pw - 36); py += 18;
        yawBox.setX(propX + 4 + 36); yawBox.setY(py); yawBox.setWidth(pw - 36); py += 18;
        pitchBox.setX(propX + 4 + 36); pitchBox.setY(py); pitchBox.setWidth(pw - 36); py += 18;
        rollBox.setX(propX + 4 + 36); rollBox.setY(py); rollBox.setWidth(pw - 36); py += 18;
        durationBox.setX(propX + 4 + 36); durationBox.setY(py); durationBox.setWidth(pw - 36); py += 18;
        stringBox.setX(propX + 4 + 36); stringBox.setY(py); stringBox.setWidth(pw - 36); py += 18;

        usePosBtn.setX(propX + 4); usePosBtn.setY(py); py += 18;
        interpBtn.setX(propX + 4); interpBtn.setY(py); py += 18;
        splineToggleBtn.setX(propX + 4); splineToggleBtn.setY(py); py += 18;
        addSplinePointBtn.setX(propX + 4); addSplinePointBtn.setY(py); py += 18;

        pathTypeBtn.setX(propX + 4); pathTypeBtn.setY(py); py += 18;

        shakeTraumaBox.setX(propX + 4 + 36); shakeTraumaBox.setY(py); shakeTraumaBox.setWidth(pw - 36); py += 18;
        shakeDecayBox.setX(propX + 4 + 36); shakeDecayBox.setY(py); shakeDecayBox.setWidth(pw - 36); py += 18;
        shakeAngleBox.setX(propX + 4 + 36); shakeAngleBox.setY(py); shakeAngleBox.setWidth(pw - 36); py += 18;
        shakeOffsetBox.setX(propX + 4 + 36); shakeOffsetBox.setY(py); shakeOffsetBox.setWidth(pw - 36); py += 18;

        lookAtXBox.setX(propX + 4 + 36); lookAtXBox.setY(py); lookAtXBox.setWidth(pw - 36); py += 18;
        lookAtYBox.setX(propX + 4 + 36); lookAtYBox.setY(py); lookAtYBox.setWidth(pw - 36); py += 18;
        lookAtZBox.setX(propX + 4 + 36); lookAtZBox.setY(py); lookAtZBox.setWidth(pw - 36); py += 18;

        orbitRadiusBox.setX(propX + 4 + 36); orbitRadiusBox.setY(py); orbitRadiusBox.setWidth(pw - 36); py += 18;
        orbitHeightBox.setX(propX + 4 + 36); orbitHeightBox.setY(py); orbitHeightBox.setWidth(pw - 36); py += 18;
        orbitSpeedBox.setX(propX + 4 + 36); orbitSpeedBox.setY(py); orbitSpeedBox.setWidth(pw - 36); py += 18;

        dollyDistanceBox.setX(propX + 4 + 36); dollyDistanceBox.setY(py); dollyDistanceBox.setWidth(pw - 36); py += 18;
    }

    @Override
    public void tick() {
        super.tick();
    }

    @Override
    public void onClose() {
        super.onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fillGradient(0, 0, width, height, 0x11000000, 0x33000000);

        graphics.fill(0, 0, width, TOPBAR_H, BG_TOP);
        graphics.renderOutline(0, TOPBAR_H - 1, width, 1, BORDER);
        if (dirty) graphics.drawString(font, "\u25CF", 110, 8, 0xFFFF4444);

        int bottomY = height - (showTimeline ? timelineH : 0);
        int cutX = showCutscenes ? cutscenePanelW : 0;
        int propX = showProperties ? width - propsPanelW : width;

        if (showCutscenes) {
            int panelBottom = height;
            graphics.fill(0, TOPBAR_H, cutscenePanelW, panelBottom, BG_PANEL);
            graphics.renderOutline(cutscenePanelW - 1, TOPBAR_H, 1, panelBottom - TOPBAR_H, BORDER);
            graphics.renderOutline(cutscenePanelW - 4, panelBottom / 2 - 10, 3, 20, 0xFF3A3A4A);

            graphics.drawString(font, "Cutscenes", 6, TOPBAR_H + 6, ACCENT);

            int listY = TOPBAR_H + 38;
            int listH = panelBottom - listY - 28;
            int visible = Math.max(0, listH / 18);

            graphics.drawString(font, "[Cutscene List]", 8, listY + 4, TEXT_DIM);
        }

        if (showTimeline) {
            int tx = cutX;
            int tw = propX - cutX;
            int ty = height - timelineH;

            graphics.fill(tx, ty, propX, height, BG_TIMELINE);
            graphics.renderOutline(tx, ty, tw, 1, BORDER);
            graphics.renderOutline(tx + tw / 2 - 10, height - 4, 20, 3, 0xFF3A3A4A);

            int headerH = 18;
            graphics.fill(tx, ty, propX, ty + headerH, 0xFF1A1A28);
            graphics.drawString(font, "Timeline", tx + 6, ty + 5, ACCENT);

            int totalTicks = 0;
            int maxTick = Math.max(totalTicks, 100);
            int tickStep = Math.max(1, (int) (20 / timelineScale));

            for (int t = 0; t <= maxTick; t += tickStep) {
                int sx = (int) (tx + 4 + t * TICK_W * timelineScale - timelineOffset);
                if (sx < tx + 4 || sx > propX - 4) continue;
                graphics.fill(sx, ty + headerH, sx + 1, height - 4, BORDER);
                if (t % (tickStep * 5) == 0) {
                    String label = String.valueOf(t);
                    int lw = font.width(label);
                    graphics.drawString(font, label, sx - lw / 2, ty + headerH + 2, TEXT_MUTE);
                }
            }

            int trackY = ty + headerH + 16;
            int trackH = timelineH - headerH - 24;
            graphics.fill(tx + 4, trackY, propX - 4, trackY + trackH, BG_TRACK);

            int phx = (int) (tx + 4 + playheadTick * TICK_W * timelineScale - timelineOffset);
            if (phx >= tx + 4 && phx <= propX - 4) {
                graphics.fill(phx - 1, ty + headerH, phx + 1, height - 4, PLAYHEAD);
                graphics.fill(phx - 4, ty + headerH - 3, phx + 4, ty + headerH, PLAYHEAD);
                graphics.fill(phx - 4, height - 4, phx + 4, height - 4 + 3, PLAYHEAD);
            }
        }
        if (showProperties) {
            graphics.fill(propX, TOPBAR_H, width, height, BG_PANEL);
            graphics.renderOutline(propX, TOPBAR_H, 1, height - TOPBAR_H, BORDER);
            graphics.renderOutline(propX + 1, height / 2 - 10, 3, 20, 0xFF3A3A4A);

            graphics.drawString(font, "Properties", propX + 6, TOPBAR_H + 6, ACCENT);

            String[] labels = {"X", "Y", "Z", "Yaw", "Pitch", "Roll", "Dur", "Val"};
            EditBox[] boxes = {xBox, yBox, zBox, yawBox, pitchBox, rollBox, durationBox, stringBox};
            for (int i = 0; i < labels.length; i++) {
                if (boxes[i].active && boxes[i].visible) {
                    graphics.drawString(font, labels[i], propX + 6, boxes[i].getY() + 2, TEXT_DIM);
                }
            }

            if (shakeTraumaBox.visible) {
                graphics.drawString(font, "Trm", propX + 6, shakeTraumaBox.getY() + 2, TEXT_DIM);
                graphics.drawString(font, "Dcy", propX + 6, shakeDecayBox.getY() + 2, TEXT_DIM);
                graphics.drawString(font, "Ang", propX + 6, shakeAngleBox.getY() + 2, TEXT_DIM);
                graphics.drawString(font, "Off", propX + 6, shakeOffsetBox.getY() + 2, TEXT_DIM);
            }
            if (lookAtXBox.visible) {
                graphics.drawString(font, "lX", propX + 6, lookAtXBox.getY() + 2, TEXT_DIM);
                graphics.drawString(font, "lY", propX + 6, lookAtYBox.getY() + 2, TEXT_DIM);
                graphics.drawString(font, "lZ", propX + 6, lookAtZBox.getY() + 2, TEXT_DIM);
            }
            if (orbitRadiusBox.visible) {
                graphics.drawString(font, "Rad", propX + 6, orbitRadiusBox.getY() + 2, TEXT_DIM);
                graphics.drawString(font, "Hgt", propX + 6, orbitHeightBox.getY() + 2, TEXT_DIM);
                graphics.drawString(font, "Spd", propX + 6, orbitSpeedBox.getY() + 2, TEXT_DIM);
            }
            if (dollyDistanceBox.visible) {
                graphics.drawString(font, "Dst", propX + 6, dollyDistanceBox.getY() + 2, TEXT_DIM);
            }

            if (splineToggleBtn.visible) {
                int spY = addSplinePointBtn.getY() + 18;
                graphics.drawString(font, "Spline Points", propX + 6, spY, ACCENT);
            }
        }

        for (var renderable : renderables) {
            if (renderable instanceof EditBox eb && !eb.visible) continue;
            if (renderable instanceof Button b && !b.visible) continue;
            if (renderable instanceof IconButton ib && !ib.visible) continue;
            renderable.render(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        for (var child : children()) {
            if (child.mouseClicked(mouseX, mouseY, button)) {
                if (child instanceof net.minecraft.client.gui.components.AbstractWidget w) setFocused(w);
                return true;
            }
        }

        int bottomY = height - (showTimeline ? timelineH : 0);
        int cutX = showCutscenes ? cutscenePanelW : 0;
        int propX = showProperties ? width - propsPanelW : width;

        if (showCutscenes && mouseX >= cutscenePanelW - 6 && mouseX <= cutscenePanelW + 3 && mouseY > TOPBAR_H && mouseY < bottomY) {
            resizingLeft = true;
            return true;
        }
        if (showProperties && mouseX >= propX - 3 && mouseX <= propX + 6 && mouseY > TOPBAR_H && mouseY < bottomY) {
            resizingRight = true;
            return true;
        }
        if (showTimeline && mouseY >= height - timelineH - 3 && mouseY <= height - timelineH + 6 && mouseX > cutX && mouseX < propX) {
            resizingTimeline = true;
            return true;
        }

        if (showCutscenes && mouseX >= 0 && mouseX <= cutscenePanelW && mouseY > TOPBAR_H && mouseY < bottomY) {
            return true;
        }

        if (showTimeline && mouseY >= height - timelineH && mouseY <= height) {
            int tx = cutX;
            int tw = propX - cutX;
            int ty = height - timelineH;
            int headerH = 18;
            int trackY = ty + headerH + 16;
            int trackH = timelineH - headerH - 24;

            if (mouseY >= height - timelineH && mouseY <= height - timelineH + headerH) {
                draggingPlayhead = true;
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (resizingLeft) {
            cutscenePanelW = (int) Math.max(MIN_PANEL_W, Math.min(MAX_PANEL_W, mouseX));
            layout();
            return true;
        }
        if (resizingRight) {
            propsPanelW = (int) Math.max(MIN_PANEL_W, Math.min(MAX_PANEL_W, width - mouseX));
            layout();
            return true;
        }
        if (resizingTimeline) {
            timelineH = (int) Math.max(MIN_TIMELINE_H, Math.min(MAX_TIMELINE_H, height - mouseY));
            layout();
            return true;
        }
        if (draggingPlayhead) {
            return true;
        }
        if (draggingAction) {
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        resizingLeft = false;
        resizingRight = false;
        resizingTimeline = false;
        draggingPlayhead = false;
        draggingAction = false;
        dragActionIndex = -1;
        dropTargetIndex = -1;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        int bottomY = height - (showTimeline ? timelineH : 0);
        if (showCutscenes && mouseX < cutscenePanelW && mouseY > TOPBAR_H && mouseY < bottomY) {
        } else if (showTimeline && mouseY > height - timelineH && mouseX > cutscenePanelW && mouseX < (showProperties ? width - propsPanelW : width)) {
        } else if (showProperties && mouseX > width - propsPanelW) {
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode != 256 && getFocused() instanceof EditBox eb) {
            if (eb.keyPressed(keyCode, scanCode, modifiers)) return true;
        }
        if (keyCode == 256) { onClose(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        for (var child : children()) {
            if (child instanceof EditBox eb && eb.isFocused() && eb.charTyped(codePoint, modifiers)) return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private static class IconButton extends net.minecraft.client.gui.components.AbstractWidget {
        private final String icon;
        private int color;
        private final Component tooltip;
        private final Runnable onClick;

        IconButton(int x, int y, int w, int h, String icon, int color, Component tooltip, Runnable onClick) {
            super(x, y, w, h, Component.empty());
            this.icon = icon;
            this.color = color;
            this.tooltip = tooltip;
            this.onClick = onClick;
        }

        void setColor(int c) { this.color = c; }

        @Override
        public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            boolean hovered = isMouseOver(mouseX, mouseY);
            int bg = hovered ? 0xFF2A2A3A : 0x001E1E28;
            if (bg != 0) graphics.fill(getX(), getY(), getX() + width, getY() + height, bg);
            if (hovered) graphics.renderOutline(getX(), getY(), width, height, ACCENT);
            int textColor = active ? (hovered ? TEXT : color) : TEXT_MUTE;
            graphics.drawCenteredString(Minecraft.getInstance().font, icon, getX() + width / 2, getY() + (height - 8) / 2, textColor);
            if (hovered && active) graphics.renderTooltip(Minecraft.getInstance().font, tooltip, mouseX, mouseY);
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (active && isMouseOver(mouseX, mouseY)) {
                onClick.run();
                return true;
            }
            return false;
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {}
    }
}