package com.iscript.iscript.gui.widget;

import com.iscript.iscript.gui.theme.Theme;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class MultiLineEditBox extends AbstractWidget {
    private final Font font;
    private String value = "";
    private int cursorPos = 0;
    private int selectStart = -1;
    private int scrollOffset = 0;
    private final int maxLength;
    private final List<String> lines = new ArrayList<>();
    private Runnable onValueChanged = null;
    private boolean draggingScroll = false;
    private static final int SCROLLBAR_W = 6;

    public MultiLineEditBox(Font font, int x, int y, int width, int height, Component title, Component hint) {
        super(x, y, width, height, title);
        this.font = font;
        this.maxLength = 8192;
    }

    public void setOnValueChanged(Runnable callback) {
        this.onValueChanged = callback;
    }

    public void setValue(String text) {
        this.value = text != null ? (text.length() > maxLength ? text.substring(0, maxLength) : text) : "";
        this.cursorPos = this.value.length();
        this.selectStart = -1;
        rebuildLines();
        ensureCursorVisible();
    }

    public String getValue() {
        return value;
    }

    private void rebuildLines() {
        lines.clear();
        String[] rawLines = value.split("\n", -1);
        int maxCharsPerLine = Math.max(1, (this.width - 10 - SCROLLBAR_W) / 6);
        for (String raw : rawLines) {
            while (raw.length() > maxCharsPerLine) {
                lines.add(raw.substring(0, maxCharsPerLine));
                raw = raw.substring(maxCharsPerLine);
            }
            lines.add(raw);
        }
        if (lines.isEmpty()) lines.add("");
    }

    private void ensureCursorVisible() {
        int lineHeight = 10;
        int visibleLines = Math.max(1, (height - 4) / lineHeight);
        int cursorLine = getLineIndex(cursorPos);
        if (cursorLine < scrollOffset) scrollOffset = cursorLine;
        if (cursorLine >= scrollOffset + visibleLines) scrollOffset = cursorLine - visibleLines + 1;
        int maxScroll = Math.max(0, lines.size() - visibleLines);
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;
        if (scrollOffset < 0) scrollOffset = 0;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!isMouseOver(mouseX, mouseY)) return false;
        setFocused(true);
        int scrollBarX = getX() + width - SCROLLBAR_W;
        if (mouseX >= scrollBarX && mouseX <= scrollBarX + SCROLLBAR_W) {
            draggingScroll = true;
            updateScrollFromMouse(mouseY);
            return true;
        }
        selectStart = -1;
        updateCursorFromMouse(mouseX, mouseY);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (!isMouseOver(mouseX, mouseY)) return false;
        int lineHeight = 10;
        int visibleLines = Math.max(1, (height - 4) / lineHeight);
        int maxScroll = Math.max(0, lines.size() - visibleLines);
        if (delta > 0) scrollOffset = Math.max(0, scrollOffset - 3);
        else scrollOffset = Math.min(scrollOffset + 3, maxScroll);
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (draggingScroll) {
            updateScrollFromMouse(mouseY);
            return true;
        }
        if (!isFocused()) return false;
        if (selectStart < 0) selectStart = cursorPos;
        updateCursorFromMouse(mouseX, mouseY);
        return true;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingScroll = false;
        return false;
    }

    private void updateScrollFromMouse(double mouseY) {
        int lineHeight = 10;
        int visibleLines = Math.max(1, (height - 4) / lineHeight);
        int maxScroll = Math.max(0, lines.size() - visibleLines);
        if (maxScroll <= 0) {
            scrollOffset = 0;
            return;
        }
        int trackY = getY() + 2;
        int trackH = height - 4;
        int thumbH = Math.max(10, (visibleLines * trackH) / lines.size());
        int trackAvail = trackH - thumbH;
        double ratio = (mouseY - trackY) / (double) trackAvail;
        scrollOffset = (int) Math.round(Math.max(0, Math.min(maxScroll, ratio * maxScroll)));
    }

    private void updateCursorFromMouse(double mouseX, double mouseY) {
        int lineHeight = 10;
        int relLine = (int) ((mouseY - getY() - 4) / lineHeight);
        int lineIndex = relLine + scrollOffset;
        if (lineIndex < 0) lineIndex = 0;
        if (lineIndex >= lines.size()) lineIndex = lines.size() - 1;
        String line = lines.get(lineIndex);
        int lineStart = getLineStart(lineIndex);
        int col = 0;
        int x = getX() + 4;
        for (int i = 0; i <= line.length(); i++) {
            int w = font.width(line.substring(0, i));
            if (x + w > mouseX) {
                col = i;
                break;
            }
            col = i;
        }
        cursorPos = lineStart + Math.min(col, line.length());
        ensureCursorVisible();
    }

    @Override
    public void setWidth(int width) {
        super.setWidth(width);
        rebuildLines();
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (!isFocused()) return false;
        if (codePoint == 1 || codePoint == 3 || codePoint == 22 || codePoint == 24) return false;
        if (isValidChar(codePoint)) {
            deleteSelection();
            insertChar(codePoint);
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!isFocused()) return false;
        boolean ctrl = (modifiers & GLFW.GLFW_MOD_CONTROL) != 0;
        boolean shift = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;

        if (ctrl && keyCode == GLFW.GLFW_KEY_A) { selectStart = 0; cursorPos = value.length(); return true; }
        if (ctrl && keyCode == GLFW.GLFW_KEY_C) {
            if (selectStart >= 0) {
                int start = Math.min(selectStart, cursorPos);
                int end = Math.max(selectStart, cursorPos);
                net.minecraft.client.Minecraft.getInstance().keyboardHandler.setClipboard(value.substring(start, end));
            }
            return true;
        }
        if (ctrl && keyCode == GLFW.GLFW_KEY_X) {
            if (selectStart >= 0) {
                int start = Math.min(selectStart, cursorPos);
                int end = Math.max(selectStart, cursorPos);
                net.minecraft.client.Minecraft.getInstance().keyboardHandler.setClipboard(value.substring(start, end));
                deleteSelection();
            }
            return true;
        }
        if (ctrl && keyCode == GLFW.GLFW_KEY_V) {
            deleteSelection();
            String clipboard = net.minecraft.client.Minecraft.getInstance().keyboardHandler.getClipboard();
            for (char c : clipboard.toCharArray()) if (isValidChar(c)) insertChar(c);
            return true;
        }

        if (ctrl && keyCode == GLFW.GLFW_KEY_HOME) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            cursorPos = 0; ensureCursorVisible(); return true;
        }
        if (ctrl && keyCode == GLFW.GLFW_KEY_END) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            cursorPos = value.length(); ensureCursorVisible(); return true;
        }
        if (ctrl && keyCode == GLFW.GLFW_KEY_LEFT) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            cursorPos = moveWordLeft(cursorPos); ensureCursorVisible(); return true;
        }
        if (ctrl && keyCode == GLFW.GLFW_KEY_RIGHT) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            cursorPos = moveWordRight(cursorPos); ensureCursorVisible(); return true;
        }

        if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (selectStart >= 0) deleteSelection();
            else if (cursorPos > 0) { value = value.substring(0, cursorPos - 1) + value.substring(cursorPos); cursorPos--; rebuildLines(); if (onValueChanged != null) onValueChanged.run(); }
            ensureCursorVisible();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DELETE) {
            if (selectStart >= 0) deleteSelection();
            else if (cursorPos < value.length()) { value = value.substring(0, cursorPos) + value.substring(cursorPos + 1); rebuildLines(); if (onValueChanged != null) onValueChanged.run(); }
            ensureCursorVisible();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            if (cursorPos > 0) cursorPos--; ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            if (cursorPos < value.length()) cursorPos++; ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            moveCursorUp(); ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            moveCursorDown(); ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            deleteSelection(); insertChar('\n'); ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_HOME) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            cursorPos = getLineStart(getLineIndex(cursorPos)); ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_END) {
            if (shift) { if (selectStart < 0) selectStart = cursorPos; } else { selectStart = -1; }
            int li = getLineIndex(cursorPos);
            cursorPos = getLineStart(li) + lines.get(li).length(); ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_TAB) {
            deleteSelection(); insertChar('\t'); ensureCursorVisible(); return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { setFocused(false); return true; }

        return false;
    }

    private int moveWordLeft(int pos) {
        if (pos <= 0) return 0;
        pos--;
        while (pos > 0 && !isWordChar(value.charAt(pos))) pos--;
        while (pos > 0 && isWordChar(value.charAt(pos - 1))) pos--;
        return pos;
    }

    private int moveWordRight(int pos) {
        if (pos >= value.length()) return value.length();
        while (pos < value.length() && !isWordChar(value.charAt(pos))) pos++;
        while (pos < value.length() && isWordChar(value.charAt(pos))) pos++;
        return pos;
    }

    private boolean isWordChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }

    private void deleteSelection() {
        if (selectStart < 0) return;
        int start = Math.min(selectStart, cursorPos);
        int end = Math.max(selectStart, cursorPos);
        value = value.substring(0, start) + value.substring(end);
        cursorPos = start;
        selectStart = -1;
        rebuildLines();
        if (onValueChanged != null) onValueChanged.run();
    }

    private void moveCursorUp() {
        int li = getLineIndex(cursorPos);
        if (li <= 0) { cursorPos = 0; return; }
        int col = getColumnInLine(cursorPos);
        int prevStart = getLineStart(li - 1);
        int prevLen = lines.get(li - 1).length();
        cursorPos = prevStart + Math.min(col, prevLen);
    }

    private void moveCursorDown() {
        int li = getLineIndex(cursorPos);
        if (li >= lines.size() - 1) { cursorPos = value.length(); return; }
        int col = getColumnInLine(cursorPos);
        int nextStart = getLineStart(li + 1);
        int nextLen = lines.get(li + 1).length();
        cursorPos = nextStart + Math.min(col, nextLen);
    }

    private int getLineIndex(int pos) {
        int count = 0;
        for (int i = 0; i < lines.size(); i++) {
            count += lines.get(i).length() + 1;
            if (count > pos) return i;
        }
        return lines.size() - 1;
    }

    private int getColumnInLine(int pos) {
        int count = 0;
        for (String line : lines) {
            if (count + line.length() >= pos) return pos - count;
            count += line.length() + 1;
        }
        return 0;
    }

    private int getLineStart(int lineIndex) {
        int count = 0;
        for (int i = 0; i < lineIndex; i++) count += lines.get(i).length() + 1;
        return count;
    }

    private void insertChar(char c) {
        if (value.length() >= maxLength) return;
        value = value.substring(0, cursorPos) + c + value.substring(cursorPos);
        cursorPos++;
        rebuildLines();
        if (onValueChanged != null) onValueChanged.run();
    }

    private boolean isValidChar(char c) {
        return (c >= 32 && c != 127) || c == '\n' || c == '\t';
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(getX(), getY(), getX() + width, getY() + height, Theme.BG_INNER);
        g.renderOutline(getX(), getY(), width, height, isFocused() ? Theme.ACCENT : Theme.BORDER);

        int lineHeight = 10;
        int visibleLines = Math.max(1, (height - 4) / lineHeight);
        int textW = width - 4 - SCROLLBAR_W;

        int scrollBarX = getX() + width - SCROLLBAR_W;
        int trackY = getY() + 2;
        int trackH = height - 4;
        g.fill(scrollBarX, trackY, scrollBarX + SCROLLBAR_W, trackY + trackH, Theme.BG_INNER);
        g.renderOutline(scrollBarX, trackY, SCROLLBAR_W, trackH, Theme.BORDER);

        int maxScroll = Math.max(0, lines.size() - visibleLines);
        if (maxScroll > 0) {
            int thumbH = Math.max(10, (visibleLines * trackH) / lines.size());
            int trackAvail = trackH - thumbH;
            int thumbY = trackY + (scrollOffset * trackAvail) / maxScroll;
            g.fill(scrollBarX, thumbY, scrollBarX + SCROLLBAR_W, thumbY + thumbH, Theme.TEXT_DIM);
        }

        if (selectStart >= 0) {
            int selStart = Math.min(selectStart, cursorPos);
            int selEnd = Math.max(selectStart, cursorPos);
            int startLine = getLineIndex(selStart);
            int endLine = getLineIndex(selEnd);

            for (int i = Math.max(startLine, scrollOffset); i <= Math.min(endLine, scrollOffset + visibleLines - 1); i++) {
                int lineStart = getLineStart(i);
                int lineEnd = lineStart + lines.get(i).length();
                int ss = Math.max(selStart, lineStart);
                int se = Math.min(selEnd, lineEnd);

                if (ss < se) {
                    String before = lines.get(i).substring(0, ss - lineStart);
                    String selected = lines.get(i).substring(ss - lineStart, se - lineStart);
                    int x1 = getX() + 4 + font.width(before);
                    int x2 = x1 + font.width(selected);
                    int y = getY() + 4 + (i - scrollOffset) * lineHeight;
                    g.fill(x1, y, x2, y + 9, 0xFF3366AA);
                }
            }
        }

        int y = getY() + 4;
        for (int i = scrollOffset; i < Math.min(lines.size(), scrollOffset + visibleLines); i++) {
            String line = lines.get(i);
            int color = Theme.TEXT;
            String trimmed = line.trim();
            if (trimmed.startsWith("//")) color = Theme.TEXT_DIM;
            else if (trimmed.startsWith("api.")) color = 0xFF88CCFF;
            else if (trimmed.startsWith("var ") || trimmed.startsWith("let ") || trimmed.startsWith("const ")) color = 0xFFFF8888;
            else if (trimmed.contains("\"") || trimmed.contains("'")) color = 0xFF88FF88;
            else if (trimmed.startsWith("if ") || trimmed.startsWith("for ") || trimmed.startsWith("while ") || trimmed.startsWith("function ")) color = 0xFFFF88FF;
            else if (trimmed.startsWith("return") || trimmed.startsWith("break") || trimmed.startsWith("continue")) color = 0xFFFFAA00;

            g.drawString(font, line, getX() + 4, y, color);
            y += lineHeight;
        }

        if (isFocused()) {
            int cursorLine = getLineIndex(cursorPos);
            int relLine = cursorLine - scrollOffset;
            if (relLine >= 0 && relLine < visibleLines) {
                int col = getColumnInLine(cursorPos);
                String lineText = lines.get(cursorLine);
                int cursorX = getX() + 4 + font.width(lineText.substring(0, Math.min(col, lineText.length())));
                int cursorY = getY() + 4 + relLine * lineHeight;
                g.fill(cursorX, cursorY, cursorX + 1, cursorY + 9, 0xFFFFFFFF);
            }
        }
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput out) {
        out.add(NarratedElementType.TITLE, Component.literal(value));
    }
}