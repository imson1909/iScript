package com.iscript.iscript.data;

import com.iscript.iscript.IScriptMod;
import com.iscript.iscript.script.ScriptFileManager;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.file.Files;
import java.nio.file.Path;

public class IScriptDataStorage {
    private static IScriptDataStorage instance;
    private final Path basePath;
    private final ServerLevel level;

    private IScriptDataStorage(ServerLevel level) {
        this.level = level;
        this.basePath = level.getServer().getWorldPath(LevelResource.ROOT).resolve("iscript");
    }

    public static void init(ServerLevel level) {
        instance = new IScriptDataStorage(level);
        ScriptFileManager.setBasePath(instance.basePath);
    }

    public static IScriptDataStorage get() {
        return instance;
    }

    public void loadAll() {
        loadGlobalStates();
    }

    public void saveAll() {
        saveGlobalStates();
    }

    private void loadGlobalStates() {
        Path file = basePath.resolve("global_states.dat");
        if (!Files.exists(file)) return;
        try {
            net.minecraft.nbt.CompoundTag tag = NbtIo.read(file.toFile());
            if (tag != null) GlobalStates.get().deserialize(tag);
        } catch (Exception e) {
            IScriptMod.LOGGER.error("Failed to load global states", e);
        }
    }

    private void saveGlobalStates() {
        Path file = basePath.resolve("global_states.dat");
        try {
            Files.createDirectories(file.getParent());
            NbtIo.write(GlobalStates.get().serialize(), file.toFile());
        } catch (Exception e) {
            IScriptMod.LOGGER.error("Failed to save global states", e);
        }
    }
}