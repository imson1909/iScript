package com.iscript.iscript.data;

import com.iscript.iscript.IScriptMod;
import com.iscript.iscript.api.states.States;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import java.io.File;
import java.nio.file.Path;

public class GlobalStates {
    private static States instance;
    private static File file;

    public static void init(Path worldFolder) {
        file = worldFolder.resolve(IScriptMod.MOD_ID + "_global_states.dat").toFile();
        instance = new States();
        load();
    }

    public static States get() {
        if (instance == null) instance = new States();
        return instance;
    }

    public static void load() {
        if (file == null || !file.exists()) return;
        try {
            CompoundTag tag = NbtIo.read(file);
            if (tag != null) instance.deserialize(tag);
        } catch (Exception e) {
            IScriptMod.LOGGER.error("Failed to load global states", e);
        }
    }

    public static void save() {
        if (file == null || instance == null) return;
        try {
            NbtIo.write(instance.serialize(), file);
        } catch (Exception e) {
            IScriptMod.LOGGER.error("Failed to save global states", e);
        }
    }

    public static void shutdown() {
        save();
        instance = null;
        file = null;
    }
}